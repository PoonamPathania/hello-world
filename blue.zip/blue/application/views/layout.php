<?php
$this->load->view($this->config->item('templates/') . 'header');
$this->load->view($this->config->item('pages/') . 'content');
$this->load->view($this->config->item('templates/') . 'footer');