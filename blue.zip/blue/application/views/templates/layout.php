<?php if($header) echo $header ;?>
 <?php if($middle) echo $middle ;?>
 <?php if($footer) echo $footer ;?>