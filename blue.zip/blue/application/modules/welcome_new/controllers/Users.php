<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends MX_Controller{
	function __construct()
    {
        parent::__construct();
    }
	public function add()
	{
		$this->load->helper('url');
		echo 'hey';die;
	}
}
?>